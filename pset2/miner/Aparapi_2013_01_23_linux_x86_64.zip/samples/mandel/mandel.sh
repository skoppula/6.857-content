java\
 -Djava.library.path=../..\
 -Dcom.amd.aparapi.executionMode=$1\
 -classpath ../../aparapi.jar:mandel.jar\
 com.amd.aparapi.sample.mandel.Main
